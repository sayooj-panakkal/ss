package com.myorg.seltestng;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.myorg.driverfactory.DriverFactory;

public class MultiBrowserTest {

	private static String URL = "http://www.calculator.net";
	private static WebDriver driver;

	@Parameters("browser")
	@Test(priority=1)
	public static void launchapp(String browser) {
		driver = DriverFactory.genDriver(browser);
		driver.get(URL);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.manage().window().maximize();
	}

	@Test(priority=2)
	public void calculatepercent() {
		// Click on Math Calculators
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	  driver.manage().window().maximize();
		
		WebElement o = driver.findElement(By.xpath("//a[contains(text(),'Math Calculators')]"));

		o.click();
		// Click on Percent Calculators
		driver.findElement(By.xpath("//a[contains(text(),'Percentage Calculator')]")).click();

		driver.manage().timeouts(). implicitlyWait(10, TimeUnit.SECONDS);

		// Enter value 10 in the first number of the percent Calculator
		driver.findElement(By.id("cpar1")).sendKeys("10");

		// Enter value 50 in the second number of the percent Calculator
		driver.findElement(By.id("cpar2")).sendKeys("50");

		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		// Click Calculate Button
		driver.findElement(By.xpath("//*[@id='content']/table[1]/tbody/tr[2]/td/input[2]")).click();

		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		// Get the Result Text based on its xpath
		String result = driver.findElement(By.xpath("//*[@id='content']/p[2]/font/b")).getText();

		// Print a Log In message to the screen
		System.out.println(" The Result is " + result);

		if (result.equals("5")) {
			System.out.println(" The Result is Pass");
		} else {
			System.out.println(" The Result is Fail");
		}
		
	}

	@AfterTest
	public void closeBrowser() {
		driver.close();
	}
}
