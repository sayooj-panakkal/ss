package com.myorg.datatproviderexcel;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.myorg.driverfactory.DriverFactory;
public class LoginDDTestExcel {
	static WebDriver driver;

	@DataProvider(name = "validLoginData")
	public Object[][] setValidLoginData() throws IOException {

		Object[][] empdata = new Object[4][2];
		int rowIndex = 0;
      	FileInputStream fin = null;
        String path="./LoginData.xls";
        File xlsFile = new File(path);
        HSSFWorkbook book=null ;
       // XSSFWorkbook book;
        fin = new FileInputStream(xlsFile);

        
        
        if(path.endsWith("xls")) {
        	
        	book = new HSSFWorkbook(fin);
        	
        }
        else if(path.endsWith("xlsx")){
        	//XSSFWorkbook book = null;
        }
		
		
		
		
		Sheet sheet = book.getSheet("empdata");
		System.out.println("Workbook created");

		for (Row row : sheet) {

			// row.getCell(1).getStringCellValue();
			String empID = row.getCell(0).getStringCellValue();
			String password = row.getCell(1).getStringCellValue();
			empdata[rowIndex][0] = empID;
			empdata[rowIndex][1] = password;
			rowIndex++;
		}

		fin.close();
		return empdata;
	}
    
	@BeforeClass
	public void initializeDriver() {

		driver = DriverFactory.genDriver("chrome");

	}

	@AfterClass
	public static void closedriver() {
		driver.close();

	}

	@Test(dataProvider = "validLoginData")
	public void testSuccessLoginLogout(String username, String password) throws InterruptedException {
		driver.get("https://opensource-demo.orangehrmlive.com/");
        Thread.sleep(3000);
		WebDriverWait wait = new WebDriverWait(driver,10);
		WebElement unameElement = wait
				.until(ExpectedConditions.presenceOfElementLocated(By.id("txtUsername")));
		unameElement.sendKeys(username);
		WebElement passElement = wait
				.until(ExpectedConditions.presenceOfElementLocated(By.id("txtPassword")));

		passElement.sendKeys(password.trim());
		Thread.sleep(3000);
		WebElement subElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.name("Submit")));
		subElement.click();
		WebElement DashboardElement = null;
		// dashboard
		DashboardElement = (new WebDriverWait(driver, 10))
				.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h1[contains(text(),'Dashboard')]")));


	}

}
