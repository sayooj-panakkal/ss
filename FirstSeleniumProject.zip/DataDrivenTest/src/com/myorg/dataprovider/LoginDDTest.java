
package com.myorg.dataprovider;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.myorg.driverfactory.DriverFactory;


public class LoginDDTest{

	WebDriver driver = null;

	@DataProvider(name = "validLoginData")
	public Object[][] setValidLoginData() {

		//

		Object[][] data = new Object[3][2];

		data[0][0] = "username0";
		data[0][1] = "password0";

		// 2nd row
		data[1][0] = "Admin";
		data[1][1] = "admin123";

		// 3rd row
		data[2][0] = "username2";
		data[2][1] = "password2";
		return data;
	}

	@BeforeClass
	public void setUp() throws NoSuchElementException {

		driver = DriverFactory.genDriver("edge");
		driver.get("https://opensource-demo.orangehrmlive.com/");


	}

	@AfterClass
	public void tearDown() {
		driver.close();

	}
	
	 
	  @AfterMethod 
	  public void navigatetorul() {
		  driver.get("https://opensource-demo.orangehrmlive.com/");
		  
		  }
	
	 
	

	@Test(dataProvider = "validLoginData")
	public void testSuccessLoginLogout(String username, String password)
			throws InterruptedException, NoSuchElementException {
		driver.manage().window().maximize();
		Thread.sleep(5000);
		//driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		WebDriverWait wait = new WebDriverWait(driver,10);
		WebElement unameElement = wait
				.until(ExpectedConditions.presenceOfElementLocated(By.name("txtUsername")));
		unameElement.sendKeys(username);
		WebElement passElement = wait
				.until(ExpectedConditions.presenceOfElementLocated(By.name("txtPassword")));

		passElement.sendKeys(password);
		//Thread.sleep(3000);
		WebElement subElement = driver.findElement(By.name("Submit"));
		subElement.click();
		WebElement DashboardElement = null;
		// logout button
		DashboardElement = wait
				.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h1[contains(text(),'Dashboard')]")));
		
	}
		 
     
	
}
