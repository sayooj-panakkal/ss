package com.myorg.titletest;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class TitleTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "E://Selenium Complete Demo//DRIVERS//chromedriver_2.exe");
		WebDriver driver = new ChromeDriver();
		 String baseUrl = "https://www.ixigo.com/";
	        String expectedTitle = "ixigo - Flights, IRCTC Train Booking, Bus Booking, Air Tickets & Hotels";
	        String actualTitle = "";
	        // launch chrome and direct it to the Base URL
	        driver.get(baseUrl);
	        driver.manage().window().maximize();
	        // get the actual value of the title
	        actualTitle = driver.getTitle();
	        System.out.println("Actual Title:"+actualTitle);

	        /*
	         * compare the actual title of the page with the expected one and print
	         * the result as "Passed" or "Failed"
	         */
	        if (actualTitle.contentEquals(expectedTitle)){
	            System.out.println("Test Passed!");
	        } else {
	            System.out.println("Test Failed");
	        }
	       
	        //close chrome
	        driver.close();

	}

}
