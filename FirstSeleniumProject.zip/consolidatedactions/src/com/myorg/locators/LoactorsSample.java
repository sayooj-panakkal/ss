package com.myorg.locators;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LoactorsSample {

	public static void main(String[] args) throws InterruptedException {
 
	 System.setProperty("webdriver.chrome.driver", "E://Selenium Complete Demo//DRIVERS//chromedriver_2.exe");
		WebDriver driver = new ChromeDriver();
 driver.get("http:\\www.demoqa.com\\");
 Thread.sleep(5000);
 
 
 /**Locate by ID Attribute
   * URL - http://www.demoqa.com/automation-practice-form
   */
 
 driver.get("https://www.demoqa.com/automation-practice-form");
 driver.findElement(By.id("firstName"));
 
 /**
   *  Locate by Name attribute
   *  URL - http://www.demoqa.com/automation-practice-form
   */
 
 driver.get("https://www.demoqa.com/automation-practice-form");
 driver.findElement(By.name("gender"));
 
 /**
   *  Locate by className attribute
   *  URL - http://www.demoqa.com/automation-practice-form
   */
 
 driver.get("https://www.demoqa.com/automation-practice-form");
 driver.findElement(By.className("practice-form-wrapper"));
 
 /**
   *  Locate by linkText and ParticalLinkText attribute
   *  URL - http://www.demoqa.com/links
   */
 
 driver.get("https://www.demoqa.com/links");
 //linkText
 driver.findElement(By.linkText("Home"));
 //partialLinkText
 driver.findElement(By.partialLinkText("Ho"));
 
 /**
   *  Locate by tagName attribute
   *  URL - http://www.demoqa.com/links
   */
 
 driver.get("https://www.demoqa.com/links");
 List <WebElement> list = driver.findElements(By.tagName("a"));
 
 
 /**
   *  Locate by cssSelector attribute
   *  URL - http://www.demoqa.com/text-box
   */
 
 driver.get("https://www.demoqa.com/text-box");
 driver.findElement(By.cssSelector("input[id= 'userName']"));
 
 
 /**
   *  Locate by xpath attribute
   *  URL - http://www.demoqa.com/text-box
   */
 
 driver.get("https://www.demoqa.com/text-box");
 driver.findElement(By.xpath("//input[@id='userName']"));
 System.out.println("Successfully located all elements.....");
 driver.close();
 
 
 
 }

}