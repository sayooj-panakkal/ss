package com.myorg.driverfactory;

import java.io.File;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.phantomjs.PhantomJSDriver;

public class DriverFactory {

	// TODO Auto-generated method stub
	public static WebDriver genDriver(String browserName) {
		WebDriver driver=null;
		switch(browserName) {
			case "chrome":
				System.setProperty("webdriver.chrome.driver", "E://Selenium Complete Demo//DRIVERS//chromedriver_2.exe");
				driver = new ChromeDriver();
				break;
			case "firefox":
				//ProfilesIni profile = new ProfilesIni();
				//FirefoxProfile myprofile = profile.getProfile("testuser");

                
				System.setProperty("webdriver.gecko.driver", "E://Selenium Complete Demo//DRIVERS//geckodriver.exe");
				driver = new FirefoxDriver();
				break;
			case "edge":
				System.setProperty("webdriver.edge.driver", "E://Selenium Complete Demo//DRIVERS//msedgedriver_2.exe");
			    driver = new EdgeDriver();
				break;
			case "phantomjs":
				  File file = new File("E://Selenium Complete Demo//DRIVERS//phantomjs.exe");				
                  System.setProperty("phantomjs.binary.path", file.getAbsolutePath());		
   			    driver = new PhantomJSDriver();
				break;
			
			
		
			default:
				System.out.println("Invalid browsername....");
				
				
				
		}
		return driver;

		

	}
}

	