package com.myorg.alert;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class AlertTest {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "E://Selenium Complete Demo//DRIVERS//chromedriver_2.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("file://E://Selenium Complete Demo//html//alert.html");
		//Click on the "Alert" button to generate the Simple Alert
		WebElement alertButton=driver.findElement(By.name("alert"));
        alertButton.click();
        //Switch the control to the Alert window
        Alert alert=driver.switchTo().alert();
        //Retrieve the message on the Alert window
        String alertMessage=alert.getText();
        System.out.println("Alert message is "+alertMessage);
        
        Thread.sleep(2000);
        //use the accept() method to accept the alert
        alert.accept();
        System.out.println("Clicked on the OK Button in the Alert Window");
        driver.close();
	}

}
