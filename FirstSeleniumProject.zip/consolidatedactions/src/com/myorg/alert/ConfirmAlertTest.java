package com.myorg.alert;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ConfirmAlertTest {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "E://Selenium Complete Demo//DRIVERS//chromedriver_2.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("file://E://Selenium Complete Demo//html//confirmalert.html");
		//Click on the "Alert" button to generate the Simple Alert
		WebElement alertButton=driver.findElement(By.name("alert"));
        alertButton.click();
        //Switch the control to the Alert window
        Alert alert=driver.switchTo().alert();
        //Retrieve the message on the Alert window
        String alertMessage=alert.getText();
        System.out.println("Alert message is "+alertMessage);
        Thread.sleep(2000);
        
        //Section1
        //Use the accept() method to accept the alert
        alert.accept();
        System.out.println("Clicked on the OK Button in the Alert Window");
        Thread.sleep(2000);
        //Refresh the webpage
        driver.getCurrentUrl();
        
        //Section 2
        //Re-generate the Confirmation Alert
        alertButton.click();
        Thread.sleep(2000);
        //Switch the control to the Alert window
        alert=driver.switchTo().alert();
        //Dismiss the Alert
        alert.dismiss();
        //Get the text returned when Cancel Button is clicked.
        WebElement cancelMessageElement=driver.findElement(By.id("msg"));
        String message=cancelMessageElement.getText();
        System.out.println(message);
        driver.close();



        

        


	
	}

}
