package com.myorg.alert;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class PromptAlertTest {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "E://Selenium Complete Demo//DRIVERS//chromedriver_2.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("file://E://Selenium Complete Demo//html//promptalert.html");
		//Click on the "continue" button to generate the Prompt Alert
		WebElement continueButton=driver.findElement(By.name("employeeLogin"));
		continueButton.click();
        //Switch the control to the Alert window
        Alert alert=driver.switchTo().alert();
        Thread.sleep(2000);
        //Typing in alert textbox
        alert.sendKeys("Sam");
        Thread.sleep(2000);
        //Clicking on ok
        alert.accept();
        //Retrieve the message on the Alert window
        String message=alert.getText();
        System.out.println("alert shows message : "+message);
        Thread.sleep(2000);
        alert.accept();
        //Get the text returned when OK Button is clicked.
        WebElement messageElement=driver.findElement(By.id("msg"));
        message=messageElement.getText();
        System.out.println("Message after accepting alert: "+message);
        Thread.sleep(2000);
        driver.close();
	}

}
