package com.myorg.imagelink;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ImageLinktest {

	public static void main(String[] args) throws InterruptedException {
		String baseUrl = "https://www.facebook.com/login/identify?ctx=recover";
		System.setProperty("webdriver.chrome.driver", "E://Selenium Complete Demo//DRIVERS//chromedriver_2.exe");
		WebDriver driver = new ChromeDriver();
		driver.get(baseUrl);
		driver.manage().window().maximize();
		Thread.sleep(2000);
		// click on the "Facebook" logo on the upper left portion
		driver.findElement(
				By.xpath("//div[@class='bp9cbjyn j83agx80 byvelhso pedkr2u6 ijkhr0an pnx7fd3z sgqwj88q f4muv6rs']"))
				.click();
		Thread.sleep(3000);
		// verify that we are now back on Facebook's homepage
		System.out.println("Current page title : " + driver.getTitle());
		if (driver.getTitle().trim().contentEquals("Facebook � log in or sign up")) {
			System.out.println("We are back at Facebook's homepage");
		} else {
			System.out.println("We are NOT in Facebook's homepage");
		}
		driver.close();

	}
}
