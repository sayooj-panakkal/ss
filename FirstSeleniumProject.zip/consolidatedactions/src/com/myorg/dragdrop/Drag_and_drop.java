
package com.myorg.dragdrop;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.myorg.driverfactory.DriverFactory;
public class Drag_and_drop {
public static void main(String[] args) throws InterruptedException {
//create driver class object
WebDriver driver = DriverFactory.genDriver("chrome");
//maximize the browser window
driver.manage().window().maximize(); 
//to delete the all cookies
driver.manage().deleteAllCookies();
driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
//navigate to the url
driver.get("https://demos.telerik.com/kendo-ui/dragdrop/index");
//using explicitly wait
WebDriverWait wait = new WebDriverWait(driver, 5);
//identify the drag and drop frame window to perform all the action
driver.findElement(By.xpath("//div[@class='demo-section k-content']"));
//to get source locator
WebElement srcwb=driver.findElement(By.id("draggable"));
System.out.println("the source element is ready to drag");
//to get target locator
 WebElement dstwb=driver.findElement(By.id("droptarget"));
System.out.println("the target element is ready to drop"); 
//create an object to the action class
Actions act=new Actions(driver);
//click and hold, and release operation
Action obj=act.clickAndHold(srcwb).moveToElement(dstwb).release().build();
obj.perform();
Thread.sleep(3000);
System.out.print("the source element is dropped to the target successfully");
//or we can use this below method
//act.dragAndDrop(srcwb, dstwb).build().perform();
//Thread.sleep(3000);
//quit the browser  
driver.quit();  
}
} 