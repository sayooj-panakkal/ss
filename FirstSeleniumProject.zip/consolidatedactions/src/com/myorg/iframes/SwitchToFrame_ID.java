package com.myorg.iframes;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.myorg.driverfactory.DriverFactory;

public class SwitchToFrame_ID {
public static void main(String[] args) throws InterruptedException {

		WebDriver driver = DriverFactory.genDriver("chrome"); //navigates to the Browser
	    driver.get("http://demo.guru99.com/test/guru99home/"); 
	       // navigates to the page consisting an iframe

	       driver.manage().window().maximize();
	       driver.switchTo().frame("a077aa5e"); //switching the frame by ID

			System.out.println("********We are switching to the iframe*******");
     		driver.findElement(By.xpath("html/body/a/img")).click();
  		    //Clicks the iframe
            Thread.sleep(5000);
  			System.out.println("*********We are done***************");
  			driver.quit();
      }
}	