package autoit;
import java.util.concurrent.TimeUnit;

import javax.swing.text.html.parser.Element;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.myorg.driverfactory.DriverFactory;
public class TestUploadFileNoAutoIT {
	
		public static void main(String[] args) {
			
			TestUploadFileNoAutoIT example = new TestUploadFileNoAutoIT();
			example.uploadFileUseAutoITChrome();
		}

		/* Upload in Chrome. */
		public void uploadFileUseAutoITChrome()
		{
			WebDriver driver = null;
			try
			{	driver = DriverFactory.genDriver("edge");
			    driver.manage().window().maximize();
				
			 driver.get("https://www.naukri.com/account/createaccount");	
			 driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			 driver.findElement(By.xpath("//button[contains(text(),'I am a Professional')]")).click();
			 WebElement ele = driver.findElement(By.xpath("//input[@name='uploadCV']"));
             ele.sendKeys("E:\\sample.rtf");
             Thread.sleep(5000);
            					
			}catch(Exception ex)
			{
				ex.printStackTrace();
			}finally
			{
				if(driver!=null)
				{
					driver.close();
					
				}
			}
		}
	}

