package autoit;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.myorg.driverfactory.DriverFactory;

public class UploadAutoIt {
@Test
public void uploadFileEx() throws IOException, InterruptedException {
	WebDriver driver =DriverFactory.genDriver("chrome");
	driver.get("https://www.naukri.com/");
	driver.manage().window().maximize();	
	driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
	WebElement ele = driver.findElement(By.xpath("//div[@class='wdgt-upload-btn']/label"));
	//ele.click();
	Thread.sleep(3000);
	//JavascriptExecutor executor = (JavascriptExecutor)driver;
	//executor.executeScript("arguments[0].click();", ele);
	Runtime.getRuntime().exec("./uploadFile.exe");
	
	driver.quit();
}
}
