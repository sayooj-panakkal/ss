package test;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.myorg.driverfactory.DriverFactory;

import PageFactory.OrangeHomePage;
import PageFactory.OrangeLogin;
import pages.OrangeHRMHomePage;
import pages.OrangeHRMLogin;


public class TestOrangeLoginWithPageFactory {

	WebDriver driver;
	OrangeHRMLogin objLogin;
	OrangeHRMHomePage objHomePage;
	
	@BeforeTest
	public  void setup(){
		
		driver = DriverFactory.genDriver("chrome");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("https://opensource-demo.orangehrmlive.com/");
	}

	/**
	 * This test go to https://opensource-demo.orangehrmlive.com/
	 * Verify login page title as orangehrm
	 * Login to application
	 * Verify the home page using Dashboard 
	 */
	@Test(priority=0)
	public void test_Home_Page_Appear_Correct(){
		//Create Login Page object
	objLogin = new OrangeHRMLogin(driver);
	//Verify login page title
	String loginPageTitle = objLogin.getLoginTitle();
	Assert.assertTrue(loginPageTitle.toLowerCase().contains("orangehrm"));
	//login to application
	objLogin.loginOrangeHRM("Admin", "admin123");
	// go the next page
	objHomePage = new OrangeHRMHomePage(driver);
	//Verify home page
	Assert.assertTrue(objHomePage.getHomePageDashboard().toLowerCase().contains("dashboard"));
	
	driver.close();}
	
}
