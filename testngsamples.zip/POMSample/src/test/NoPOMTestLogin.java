package test;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.myorg.driverfactory.DriverFactory;


public class NoPOMTestLogin {

	/**
	 * This test go to https://opensource-demo.orangehrmlive.com/
	 * Verify login page title as orangehrm
	 * Login to application
	 * Verify the home page using Dashboard 
	 */
	@Test(priority=0)
	public void test_Home_Page_Appear_Correct(){
		WebDriver driver = DriverFactory.genDriver("chrome");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("https://opensource-demo.orangehrmlive.com/");
		//Find user name and fill user name
	    driver.findElement(By.name("txtUsername")).sendKeys("Admin");
	    //find password and fill it
	    driver.findElement(By.name("txtPassword")).sendKeys("admin123");
	    //click login button
	    driver.findElement(By.name("Submit")).click(); 
	    String homeText = driver.findElement(By.xpath("//h1[contains(text(),'Dashboard')]")).getText();
	    //verify login success
	    System.out.println(homeText);
		Assert.assertTrue(homeText.trim().contains("Dashboard"));
		driver.close();
	}
	
}
