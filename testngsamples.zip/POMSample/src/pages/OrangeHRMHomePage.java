package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class OrangeHRMHomePage {

	WebDriver driver;
	By homePageUserName = By.xpath("//h1[contains(text(),'Dashboard')]");
	
	public OrangeHRMHomePage(WebDriver driver){
		this.driver = driver;
	}
	
	//Get the User name from Home Page
		public String getHomePageDashboard(){
		 return	driver.findElement(homePageUserName).getText();
		}
}
