package PageFactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class OrangeHomePage {

	WebDriver driver;
	@FindBy(xpath="//h1[contains(text(),'Dashboard')]")
	@CacheLookup
	WebElement homePageDashBoard;
	
	public OrangeHomePage(WebDriver driver){
		this.driver = driver;
		//This initElements method will create  all WebElements
		PageFactory.initElements(driver, this);
	}
	
	//Get the User name from Home Page
		public String getHomePageDashboarde(){
		 return	homePageDashBoard.getText();
		}
}
