package example;

	

	import org.openqa.selenium.By;		
	import org.openqa.selenium.WebDriver;		
	import org.openqa.selenium.firefox.FirefoxDriver;		
	import org.testng.Assert;		
	import org.testng.annotations.Test;

import com.myorg.driverfactory.DriverFactory;

import org.testng.annotations.BeforeTest;	
	import org.testng.annotations.AfterTest;		
	public class TitleTest {		
		    private WebDriver driver;		
			@Test				
			public void testEasy() {
				driver.get("https://www.ixigo.com/");  
				String title = driver.getTitle();				
				Assert.assertTrue(title.contains("ixigo - Flights, IRCTC Train Booking, Bus Booking, Air Tickets & Hotels")); 		
			}	
			@BeforeTest
			public void beforeTest() {	
				driver=DriverFactory.genDriver("edge");
			}		
			@AfterTest
			public void afterTest() {
				driver.quit();			
			}		
	}	

